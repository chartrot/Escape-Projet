#pragma once
#include "Objet.hpp"
#include "Case.hpp"
#include "Joueur.hpp"
class ObjetDeverouilleur : public Objet {
	//Objet permettant de d�verouiller des pieces lorsqu'on l'utilise (cl� dans l'�nonc�)

public:
	ObjetDeverouilleur(std::string nom, std::string description, std::vector<std::string> motsImportants, bool estPrenable,
		std::string descriptionPrendre, std::pair<Direction, Case*> caseCachee, Case* caseVoisine, Joueur* joueur);
	void interagir() override;

private:
	std::pair<Direction, Case*> connexionCachee_; //Connexion qui sera ajoutee
	Case* caseObjetUtilisable_; //Case ou on a le droit d'utiliser l'objet
	Joueur* joueur_;// attribut joueur pour acceder plus facilement a sa case actuelle
};