#pragma once
#include <string>
enum Direction {// les differentes directions ou on peut se deplacer
	N,
	S,
	E,
	O
};
std::string directionToString(const Direction& dir);
