#pragma once
#include <vector>
#include "Case.hpp"
#include "memory"
class Carte {// Classe qui a la possession de la m�moire de toutes les cases du jeu
public : 
	Carte();// constructeur par d�faut
	~Carte();// destructeur
	void ajouterCase(std::unique_ptr<Case> c);// ajouter une case � la carte
private : 
	std::vector<std::unique_ptr<Case>> cases_;// vecteur de cases
};
