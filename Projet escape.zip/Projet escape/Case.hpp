#pragma once
#include <string>
#include <unordered_map>
#include <memory>
#include <iostream>
#include "Objet.hpp"
#include "Direction.hpp"

class Case// classe repr�sentant une zone du jeu
{
public :
	Case(const std::string nom, const std::string desc);
	~Case();
	void ajouterVoisin(const Direction& d, Case* c);
	std::unique_ptr<Objet> getObjetATransferer(const std::string& chaine); 
	void ajouterObjetCase(std::unique_ptr<Objet> obj);
	std::vector<std::unique_ptr<Objet>>& getListeObjets(){
		return listeObjets_;
	}
	const std::string& getNom() const { return nom_; } 
	const std::string& getDescription() const { return description_;} 
	std::unordered_map<Direction, Case*> getVoisins() { return voisins_; }
	Case* validerVoisin(const Direction& d);
	friend std::ostream& operator<<(std::ostream& os, const Case& c);
private : 
	std::string nom_;// attribut repr�sentant le nom de la case
	std::string description_; // attribut repr�sentant la description de la case
	std::unordered_map<Direction, Case*> voisins_; // conteneur associatif qui associe une direction ( cl� ) � une valeur
	std::vector<std::unique_ptr<Objet>> listeObjets_;// conteneur qui contient tous les objets dans la classe
};