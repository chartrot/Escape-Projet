/*
* Projet A2024 INF1015
* \file   Joueur.cpp
* \author Lestage (2376325) et Trottier(2376909)
* \date 8 decembre 2024
* Cr�� le 1 decembre 2024
*/
#include "Joueur.hpp"
#include <memory>
using namespace std;

Joueur::Joueur() {}
Joueur::~Joueur(){}

ostream& operator<<(ostream& os, const Joueur& j) {
	os << *j.caseActuelle_;
	os << "Tu as: " << endl;
	for (auto& o : j.objetsJoueur_) {
		os << o->getNom() << endl;
	}
	return os;
}

void Joueur::regarderObjet(ostream& os, const string& commande) {// JEREMIE regarder l'objet
	if (commande.empty()) {
		os << *this;
	}
	else if (objetPresentSalleActuelle(commande)){
		for (auto& o : caseActuelle_->getListeObjets()) {
			if (o->contientMotImportant(commande)) {
				o->regarder();
			}
		}
	}
	else if (objetPresentInventaire(commande)) {
		for (auto& o : objetsJoueur_) {
			if (o->contientMotImportant(commande)) {
				o->regarder();
			}
		}
	}
	else{
		os << "Vous ne pouvez pas regarder cela" << endl;
	}
	os << "> ";
}

bool Joueur::objetPresentSalleActuelle(const string& commande) {// JEREMIE retourne bool si il y a l'objet dans la commande dans la case actuelle
	for (auto& o : caseActuelle_->getListeObjets()) {
		if (o->contientMotImportant(commande)) {
			return true;
		}
	}
	return false;
}
bool Joueur::objetPresentInventaire(const string& commande) {// retourne true si l'objet est dans l'inventaire du joueur
	for (auto& o : objetsJoueur_) {
		if (o->contientMotImportant(commande)) {
			return true;
		}
	}
	return false;
}
void Joueur::prendreObjet(ostream& os, const string& commande) {
	if (objetPresentSalleActuelle(commande)){
		for (auto& o : caseActuelle_->getListeObjets()) {
			if (o->contientMotImportant(commande)) {
				o->prendre();// affiche le message quand il essaie de prendre
				os << "> ";
			}
		}
		for (auto& o : caseActuelle_->getListeObjets()) {
			if (o->contientMotImportant(commande) && o->getEstPrenable()) {// pour trouver le bon objet et savoir si il eest prenable
				objetsJoueur_.push_back(move(caseActuelle_->getObjetATransferer(commande)));
				return;
			}
		}
	}
	else{
		os << "Vous ne pouvez pas prendre cela" << endl;
		os << "> ";
	}
	
}

void Joueur::utiliserObjet(ostream& os, const string& commande) {// utiliser l'objet
	if (objetPresentSalleActuelle(commande)) {
		for (auto& o : caseActuelle_->getListeObjets()) {
			if (o->contientMotImportant(commande)) {
				o->interagir();
			}
		}
	}
	else if(objetPresentInventaire(commande)) {
		for (auto& o : objetsJoueur_) {
			if (o->contientMotImportant(commande)) {
				o->interagir();
			}
		}
	}
	else {
		os << " Vous ne pouvez pas utiliser ca " << endl;
	}
	os << "> ";
}
void Joueur::deplacer(ostream& os, Direction d) {
	auto nouvelleCaseActuelle = caseActuelle_->validerVoisin(d);
	if (nouvelleCaseActuelle != nullptr)
	{
		caseActuelle_ = nouvelleCaseActuelle;
		os << *this;
	}
	else{
		os << "Deplacement impossible" << endl;
		
	}
	os << "> ";
}