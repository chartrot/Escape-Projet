/*
* Projet A2024 INF1015
* \file   Case.cpp
* \author Lestage (2376325) et Trottier(2376909)
* \date 8 decembre 2024
* Cr�� le 1 decembre 2024
*/
#include "Case.hpp"
using namespace std;

Case::Case(string nom, string desc): nom_(nom), description_(desc) {} 
Case::~Case() {}

void Case::ajouterVoisin(const Direction& d, Case* c) {// ajouter une case voisine en ajoutant la methode insert()
	voisins_.insert({d,c});
}

void Case::ajouterObjetCase(unique_ptr<Objet> obj) {// ajouter l'objet � son inventaire
	listeObjets_.push_back(move(obj));
}
unique_ptr<Objet> Case::getObjetATransferer(const string& chaine) { //s'occupe du transfer de possession entre la case et le joueur.
	for (auto it = listeObjets_.begin(); it != listeObjets_.end(); ++it) {
		if ((*it)->contientMotImportant(chaine)) {
			// Transf�rer la propri�t� de l'objet
			auto obj = move(*it);
			// Supprimer l'�l�ment de la liste
			listeObjets_.erase(it);
			return obj;
		}
	}
	return nullptr;
}
ostream& operator<<(ostream& os, const Case& c) {
	os << c.nom_ << endl; 
	os << c.description_ << endl;
	os << "Tu vois :" << endl;
	for (auto& o : c.listeObjets_) {
		os << *o << endl;
	}
	for (auto& m : c.voisins_) { //directionToString d�finie dans Direction.hpp
		os << m.second->getNom() << " est � la direction " << directionToString(m.first) << endl; 
	}
	return os;
}

Case* Case::validerVoisin(const Direction& d) {// retourner un pointeur vers un voisin selon une cl� direction, s'il existe sinon null
	auto i = voisins_.find(d);
	if ( i != voisins_.end() ){
		return i->second;
	}
	return nullptr;
}
