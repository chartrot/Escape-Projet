/*
* Projet A2024 INF1015
* \file   ObjetInteractif.cpp
* \author Lestage (2376325) et Trottier(2376909)
* \date 8 decembre 2024
* Cr�� le 1 decembre 2024
*/
#include "ObjetDeverouilleur.hpp"

using namespace std;


ObjetDeverouilleur::ObjetDeverouilleur(string nom, string description, vector<string> motsImportants, bool estPrenable,
	string descriptionPrendre, pair<Direction, Case*> caseCachee, Case* caseVoisine, Joueur* joueur)
	: Objet(nom, description, motsImportants, estPrenable, descriptionPrendre), connexionCachee_(caseCachee), caseObjetUtilisable_(caseVoisine), joueur_(joueur)  {
}

void ObjetDeverouilleur::interagir() {
	if (joueur_->getCaseActuelle() == caseObjetUtilisable_ && joueur_->getCaseActuelle()->validerVoisin(connexionCachee_.first)==nullptr)  {// si la case du joueur est la case ou la cl� peut etre utilis�e et si elle na pas �t� d�ja utilis�e
		caseObjetUtilisable_->ajouterVoisin(connexionCachee_.first, connexionCachee_.second);// ajoute la case cach�e � la case actuelle
		cout << "Un passage vers la salle " << connexionCachee_.second->getNom() << "S'ouvre" << endl;
	}
	else {
		cout << "L'objet ne peut pas �tre utilis� ici" << endl;
	}
}