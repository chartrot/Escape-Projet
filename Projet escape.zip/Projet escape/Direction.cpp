/*
* Projet A2024 INF1015
* \file   Direction.cpp
* \author Lestage (2376325) et Trottier(2376909)
* \date 8 decembre 2024
* Cr�� le 1 decembre 2024
*/
#include "Direction.hpp"

//Permet de convertir la direction en string pour faciliter l'affichage.
//Ne fait pas partie du enum, mais on a d�cid� de mettre cette fonction ici, car elle manipule seulement des directions.
std::string directionToString(const Direction& dir) {
 	switch (dir) {
 	case N: return "Nord (N)";
 	case S: return "Sud (S)";
 	case E: return "Est (E)";
  	case O: return "Ouest (O)";
 	default: return "Inconnu";
 	}
}
//On a d�cider de faire nos propres m�thodes (meme si c'est plus long) au 
//lieu d'utiliser la bilbioth�que magic_enum pour s'assurer du bon fonctionnement en fonction de la tache demand�e