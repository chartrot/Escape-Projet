/*
* Projet A2024 INF1015
* \file   ObjetInteractif.cpp
* \author Lestage (2376325) et Trottier(2376909)
* \date 8 decembre 2024
* Cr�� le 1 decembre 2024
*/
#include "ObjetInteractif.hpp"


using namespace std;

ObjetInteractif::ObjetInteractif(string nom, string description, vector<string> motsImportants, bool estPrenable, string descriptionPrendre, string action )
	: Objet(nom, description, motsImportants, estPrenable, descriptionPrendre), action_(action) {}

void ObjetInteractif::interagir() {// on affiche l'action de l'objet
	cout  << action_ << endl;
}	