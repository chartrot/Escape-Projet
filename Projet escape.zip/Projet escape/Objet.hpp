#pragma once
#include <string>
#include <vector>
#include <iostream>
class Objet {
	// Classe de base et parent d'objet int�ratif, objet d�verouilleur et objet acc�s
public :
	Objet(std::string nom, std::string description, std::vector<std::string> motsImportants, bool estPrenable, std::string descriptionPrendre);
	virtual ~Objet() = default;
	virtual void interagir() = 0;// methode virtuelle pure qui represente l'action principale, differente pour chaque objet( use )
	void prendre();
	void regarder();
	bool contientMotImportant(const std::string& chaine);
	const std::string getNom () const  {return nom_; }
	bool getEstPrenable() {return estPrenable_; }
	friend std::ostream& operator<<(std::ostream& os, const Objet& o);
	
private:
	bool estPrenable_;// attribut bool�en qui d�finit si un objet est prenable ou non.
	std::string descriptionPrendre_;//description qui s'affiche si l'utilisateur peut prendre ou non l'objet.
	std::string nom_;// nom de l'objet
	std::string description_;// description de l'objet
	std::vector<std::string> motsImportants_;//Vecteur qui contient les mots importants de chaque objet.
};

