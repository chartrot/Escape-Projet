#pragma once
#include<iostream>
#include "Case.hpp"
class Joueur {// classe qui represente le joueur
public:
	Joueur();
	~Joueur();
	void setCaseActuelle(Case* caseDep) {
		caseActuelle_ = caseDep;
	}
	void regarderObjet(std::ostream& os, const std::string& commande);
	void utiliserObjet(std::ostream& os, const std::string& commande);
	void prendreObjet(std::ostream& os, const std::string& commande);// Methode quand il prend l'objet
	void deplacer(std::ostream& os, Direction d);
	Case* getCaseActuelle() const { return caseActuelle_; }
	friend std::ostream& operator<<(std::ostream& os, const Joueur& j);
	bool objetPresentSalleActuelle(const std::string& chaine);
	bool objetPresentInventaire(const std::string& chaine); //methode qui check si l'objet est dans l'inventaire du joeuur qui va nous etre utile plus tard
	
private:
	std::vector<std::unique_ptr<Objet>> objetsJoueur_;// liste d'objets du joueur 
	Case* caseActuelle_ = nullptr;// case actuelle du joueur, initialilement a nullptr mais on lui donne avec un setter
};
