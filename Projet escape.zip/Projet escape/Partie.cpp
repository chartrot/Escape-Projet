/*
* Projet A2024 INF1015
* \file   Partie.cpp
* \author Lestage (2376325) et Trottier(2376909)
* \date 8 decembre 2024
* Cr�� le 1 decembre 2024
*/
#include "Partie.hpp"
#include "Direction.hpp"
#include <memory>
#include <iostream>
#include <algorithm>
#include <sstream>

using namespace std;

Partie::Partie() {
	joueur_ = make_unique<Joueur>();
}
Partie::~Partie(){}


void Partie::initialiserCommandes() {
	commandesActions_["look"] = [this](const string& arguments) { joueur_->regarderObjet(cout, arguments); };
	commandesActions_["use"] = [this](const string& arguments) { joueur_->utiliserObjet(cout, arguments); };
	commandesActions_["take"] = [this](const string& arguments) {joueur_->prendreObjet(cout, arguments); };
	commandesActions_["exit"] = [this](const string&) { cout << " Merci d'avoir jou� � Escape The Matrix !!" << endl;};
	//Lambda pour chaque direction
	commandesActions_["N"] = [this](const string&) { joueur_->deplacer(cout, N); };
	commandesActions_["S"] = [this](const string&) { joueur_->deplacer(cout, S); };
	commandesActions_["E"] = [this](const string&) { joueur_->deplacer(cout, E); };
	commandesActions_["O"] = [this](const string&) { joueur_->deplacer(cout, O);};
}


void Partie::instancierMonde() {
	//Cr�ation des salles
	unique_ptr foyer = make_unique<Case>("-- Entree --",
		"Vous etes dans l'entree de la maison. Il y a un bizarre de tapis sur le sol");
	unique_ptr salon = make_unique<Case>("-- Salon --",
		"Vous etes dans le salon. Il y a un bureau d'ordinateur avec des cam�ras et un �cran bleu. Il y a une tele et un sofa a cote.");
	unique_ptr couloir = make_unique<Case>("-- Couloir --",
		"Vous etes dans le couloir principal. Il y a beaucoup de boites contre le mur.");
	unique_ptr petiteChambre = make_unique<Case>("-- Petite chambre --",
		"Vous etes dans la petite chambre. Elle n'est pas vraiment propre et organis�e. Il y a une petite fenetre.");
	unique_ptr cuisine = make_unique<Case>("-- Cuisine --",
		"Vous etes dans la cuisine. Il y a plusieurs casseroles empilees. La vaisselle n'est pas propre.");
	unique_ptr chambreR = make_unique<Case>("-- Chambre R --", " C'est une chambre bizzare avecc des murs rouges");
	unique_ptr grenier = make_unique<Case>("-- Grenier sombre --", " Le grenier est sombre, tu vois une echelle qui descend vers le bas ");

    //Cr�ation des objets
	unique_ptr piano = make_unique<ObjetInteractif>("Un vieux piano �lectrique", "Ceci est un vieux piano Yamah avec 61 touches. Il vient des ann�es 90s",
		vector<string>{ "piano","electrique" },false," Ce piano est trop dur � transporter", "Vous jouez quelques notes sur le piano, il ne fait pas un beau bruit");
	unique_ptr cle = make_unique<ObjetDeverouilleur>("Une cle verte", "Cette vieille cl� contient un myst�re", vector<string>{ "cle", "verte" },
	true, "Vous prenez la cl� peut etre que vous allez trouver o� elle m�ne", make_pair(E, chambreR.get()), couloir.get(), joueur_.get());
	unique_ptr echelle1 = make_unique<ObjetAcces>("Une echelle qui va vers une trappe", "Cette echelle est de m�tal rouill� ", vector<string>{ "echelle" },
	false, "Cet �chelle est fixe vous ne pouvez pas la prendre ", grenier.get(), joueur_.get());
	unique_ptr echelle2 = make_unique<ObjetAcces>("Une echelle qui descend", "Cette echelle est de m�tal rouill� ", vector<string>{ "echelle" },
	false, "Cet �chelle est fixe vous ne pouvez pas la prendre ", petiteChambre.get(), joueur_.get());
	  
	//Ajout et connexion des voisins entre les cases cr��es, le .get() permet de convertir en pointeur brut pour �viter un transfert de possession
	chambreR->ajouterVoisin(O, couloir.get());
	foyer->ajouterObjetCase(move(cle));
	foyer->ajouterObjetCase(move(piano));
	petiteChambre->ajouterObjetCase(move(echelle1));
	grenier->ajouterObjetCase(move(echelle2));
	foyer->ajouterVoisin(E, salon.get()); 
	foyer->ajouterVoisin(N, couloir.get());
	salon->ajouterVoisin(O, foyer.get());
	couloir->ajouterVoisin(S, foyer.get());
	couloir->ajouterVoisin(O, petiteChambre.get());
	couloir->ajouterVoisin(N, cuisine.get());
	petiteChambre->ajouterVoisin(E, couloir.get());
	cuisine->ajouterVoisin(S, couloir.get());
	//Case de d�part � l'aide d'une fonction, au cas ou on aimerait la changer. (Case de d�part pr�d�termin�e)
	joueur_->setCaseActuelle(foyer.get());
	//Ajout des cases dans la carte (transfer de possession)
	carte_.ajouterCase(move(foyer));
	carte_.ajouterCase(move(salon));
	carte_.ajouterCase(move(couloir));
	carte_.ajouterCase(move(petiteChambre));
	carte_.ajouterCase(move(cuisine));	
	carte_.ajouterCase(move(chambreR));
	carte_.ajouterCase(move(grenier));
}

void Partie::demarrer(){  //m�thode qui commence la partie 
	instancierMonde();
	initialiserCommandes();
	cout << ">>>>>>>> INF1015 Escape The Matrix 2024 <<<<<<<<" << endl;
	cout << *joueur_;
	cout << "> ";
	gererCommandes();
}

bool Partie::estCommandeValide(const string& input) const {
	// V�rifie si l'entr�e est dans les commandes valides ou dans la map des commandes
	//Disponible dans la biblioth�que algorithm de STL, nous avons d�cides de prendre une lamba pour r�duire le nombre de lignes et augmenter l'efficacit�
	//Anyof permet de parcourir les commandes valides pour ensuite utiliser la lambda. Donc, il recherche dans les deux conteneurs si le input est pr�sent
	return any_of(commandesValides_.begin(), commandesValides_.end(), 
		[&input](const string& commande) { return input.find(commande) != string::npos;  }) ||
		commandesDirections.find(input) != commandesDirections.end();
} 

void Partie::gererCommandes() { //g�re les commandes lorsque le jeu est en cours et s'occupe de l'arreter au bon moment
	string commande;
	do {
		getline(cin, commande, '\n');// chang� � un getline parce que maintenant l'utilisateur peut ecrire plusieurs mots
		if (estCommandeValide(commande)) {
			traiterCommande(commande);
		}
		else{
			cout << "Je ne sais pas ca " << endl;
			cout << "> ";
		}
	} while (commande != "exit");
}

void Partie::traiterCommande(const string& commande) {// methode qui traite les commandes valides ( d�termine quel sont  // Trouve la position du premier espace dans la commande
	size_t espacePos = commande.find(' ');

	// Extrait le premier mot
	string premierMot;
	if (espacePos != string::npos) {
		premierMot = commande.substr(0, espacePos);
	}
	else {
		premierMot = commande;
	}

	// Cherche le premier mot dans le map commandesActions_
	auto it = commandesActions_.find(premierMot);
	if (it != commandesActions_.end()) {
		// R�cup�re le reste des arguments apr�s le premier mot
		string arguments;
		if (espacePos != string::npos) {
			arguments = commande.substr(espacePos + 1);
		}
		else {
			arguments = "";
		}

		// Passe les arguments � la fonction associ�e, donc on appelle la fonction associ�e � l'argument dans initialiser commandes
		it->second(arguments);
	}
}
