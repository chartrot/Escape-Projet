/*
* Projet A2024 INF1015
* \file   Carte.cpp
* \author Lestage (2376325) et Trottier(2376909)
* \date 8 decembre 2024
* Cr�� le 1 decembre 2024
*/
#include "Carte.hpp"
using namespace std;

Carte::Carte(){}
Carte::~Carte(){}

void Carte::ajouterCase(unique_ptr<Case> c) {// ajouter une case � la carte
	cases_.push_back(move(c));
}