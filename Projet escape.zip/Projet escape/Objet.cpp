/*
* Projet A2024 INF1015
* \file   ObjetInteractif.cpp
* \author Lestage (2376325) et Trottier(2376909)
* \date 8 decembre 2024
* Cr�� le 1 decembre 2024
*/
#include "Objet.hpp"

using namespace std;

Objet::Objet(string nom, string description, vector<string> motsImportants, bool estPrenable, string descriptionPrendre)
    : nom_(nom), description_(description), motsImportants_(motsImportants), 
    estPrenable_(estPrenable), descriptionPrendre_(descriptionPrendre)
{}


bool Objet::contientMotImportant(const string& chaine) {//Regarde dans son vecteur de mots Importants si il y a un mot dans la commande ( chaine ) qui est important, si oui return true 
    for (const auto& mot : motsImportants_) {
        if (chaine.find(mot) != string::npos) {
            return true;
        }
    }
    return false;
}

void Objet::regarder() {// afficher la description de l'objet quand on le regarde
    cout << description_ << endl;
}

void Objet::prendre() {// affiche la phrase quand l'objet essaie de prendre l'objet
    cout << descriptionPrendre_ << endl;
}

ostream& operator<<(ostream& os, const Objet& obj) {
    os << obj.nom_ << endl;
    return os;
}