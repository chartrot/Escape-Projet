#include "Carte.hpp"
#include "Joueur.hpp"
#include "ObjetAcces.hpp"
#include "ObjetDeverouilleur.hpp"
#include "ObjetInteractif.hpp"
#include "map"
#include <functional>
#pragma once
class Partie {// classe qui gere toute la partie

public:
	Partie();
	~Partie();
	void demarrer();
private:
	void instancierMonde();
	void gererCommandes();
	bool estCommandeValide(const std::string& input) const;
	void traiterCommande(const std::string& commande);
	void initialiserCommandes();
	Carte carte_;// attribut carte
	std::unique_ptr<Joueur> joueur_;// attribut joueur
	//probablement en commentaire ci-dessous
	std::unordered_map<std::string, Direction> commandesDirections = { // pour associer une commande � une direction
		{ "N", N },
		{ "S", S },
		{ "E", E },
		{ "O", O }
	};
	const std::vector<std::string> commandesValides_{ "look", "exit", "use", "take"};
	std::map<std::string, std::function<void(const std::string&)>> commandesActions_;// les fonctions associ�es � chaque commandes
};
