/*
* Projet A2024 INF1015
* \file   ObjetInteractif.cpp
* \author Lestage (2376325) et Trottier(2376909)
* \date 8 decembre 2024
* Cr�� le 1 decembre 2024
*/
#include "ObjetAcces.hpp"
using namespace std;

ObjetAcces::ObjetAcces(string nom, string description, vector<string> motsImportants,
	bool estPrenable, string descriptionPrendre, Case* caseAcces, Joueur* joueur) :
	Objet(nom, description, motsImportants, estPrenable, descriptionPrendre), caseAccedee_(caseAcces), joueur_(joueur) {
}

void ObjetAcces::interagir() {
	cout << "Tu utilise " << getNom() << endl;
	joueur_->setCaseActuelle(caseAccedee_);// d�placement du joueur � la case que l'objet m�ne 
	cout << *joueur_ << endl;// afficher la nouvelle position du joueur et ses objets
}

