#pragma once
#include "Objet.hpp"
class ObjetInteractif : public Objet  {
		//Les objets interactifs sont des objets comme le piano de l'�nonc�
public:
	ObjetInteractif(std::string nom, std::string description, std::vector<std::string> motsImportants, bool estPrenable, std::string descriptionPrendre,  std::string action_);
	void interagir() override;
private: 
	std::string action_;// attribut qui sera affiche quand un joueur utilise l'objet
};
