#pragma once
#include "Objet.hpp"
#include "Case.hpp"
#include "Joueur.hpp"
class ObjetAcces : public Objet {
	//Permet de donner acc�s � une case adjacente lorsqu'on utilise cet objet par exemple echelle dans l'enonce

public:
	ObjetAcces(std::string nom, std::string description, std::vector<std::string> motsImportants,
		bool estPrenable, std::string descriptionPrendre,Case* caseAcces_, Joueur* joueur);
	void interagir() override;

private:
	Case* caseAccedee_;// case que le joueur va se rendre apres avoir utiliser l'objet
	Joueur* joueur_;//  attribut joueur pour acceder plus facilement � sa case actuelle
};